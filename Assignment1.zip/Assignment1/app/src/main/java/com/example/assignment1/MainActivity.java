package com.example.assignment1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.media.MediaPlayer;
import android.os.Vibrator;
import android.util.DisplayMetrics;
import android.view.Display;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.RotateAnimation;
import android.view.animation.ScaleAnimation;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.view.MotionEvent;
import java.util.Random;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    private int actualAnswer, userAnswer, number1, number2;
    private static MediaPlayer mp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView apple = (ImageView) findViewById(R.id.apple1);
        apple.setOnTouchListener(handleTouch);


        ImageView apple2 = (ImageView) findViewById(R.id.apple2);
        apple2.setOnTouchListener(handleTouch);

        ImageView apple3 = (ImageView) findViewById(R.id.apple3);
        apple3.setOnTouchListener(handleTouch);

        ImageView apple4 = (ImageView) findViewById(R.id.apple4);
        apple4.setOnTouchListener(handleTouch);

        ImageView apple5 = (ImageView) findViewById(R.id.apple5);
        apple5.setOnTouchListener(handleTouch);

        ImageView apple6 = (ImageView) findViewById(R.id.apple6);
        apple6.setOnTouchListener(handleTouch);

        ImageView apple7 = (ImageView) findViewById(R.id.apple7);
        apple7.setOnTouchListener(handleTouch);

        ImageView apple8 = (ImageView) findViewById(R.id.apple8);
        apple8.setOnTouchListener(handleTouch);

        ImageView apple9 = (ImageView) findViewById(R.id.apple9);
        apple9.setOnTouchListener(handleTouch);

        createQuestion();
    }

    private View.OnTouchListener handleTouch = new View.OnTouchListener() {
        float dx, dy, newX, newY;
        @Override
        public boolean onTouch(View view, MotionEvent event){
            mp = MediaPlayer.create(getApplicationContext(), R.raw.pop);
            switch(event.getAction()){
                case MotionEvent.ACTION_DOWN:
                    mp.start();
                    clearMediaPlayer();

                    dx = view.getX() - event.getRawX();
                    dy = view.getY() - event.getRawY();
                    break;
                case MotionEvent.ACTION_MOVE:
                    newX = event.getRawX() + dx;
                    newY = event.getRawY() + dy;

                    view.animate()
                            .x(newX)
                            .y(newY)
                            .setDuration(0)
                            .start();
                    break;
                default:
                    return false;
            }
            return true;
        }
    };

    private void createQuestion()
    {

        Random rand = new Random();
        do
        {
            number1 = rand.nextInt(10);
            number2 = rand.nextInt(10);
        }while(number1 + number2 > 9);
        actualAnswer = number1 + number2;
        TextView questionText = (TextView)findViewById(R.id.question);
        questionText.setText(number1 + " + " + number2 + " = ?" );
    }

    private void compareAnswer()
    {

        if(userAnswer == actualAnswer)
        {
            setupFinishView();
            mp = MediaPlayer.create(this, R.raw.button);
            mp.start();
            clearMediaPlayer();
        }
        else if(userAnswer != actualAnswer){
            Vibrator v = (Vibrator) getApplicationContext().getSystemService(getApplicationContext().VIBRATOR_SERVICE);
            v.vibrate(500);
            mp = MediaPlayer.create(this, R.raw.wrong);
            mp.start();
            clearMediaPlayer();
        }
    }

    public void buttonPress(View myView)
    {
        switch (myView.getId())
        {
            case R.id.zero:
                userAnswer = 0;
                compareAnswer();
                break;

            case R.id.one:
                userAnswer = 1;
                compareAnswer();
                break;

            case R.id.two:
                userAnswer = 2;
                compareAnswer();
                break;

            case R.id.three:
                userAnswer = 3;
                compareAnswer();
                break;

            case R.id.four:
                userAnswer = 4;
                compareAnswer();
                break;

            case R.id.five:
                userAnswer = 5;
                compareAnswer();
                break;

            case R.id.six:
                userAnswer = 6;
                compareAnswer();
                break;

            case R.id.seven:
                userAnswer = 7;
                compareAnswer();
                break;

            case R.id.eight:
                userAnswer = 8;
                compareAnswer();
                break;

            case R.id.nine:
                userAnswer = 9;
                compareAnswer();
                break;

            case R.id.PlayAgain:
                mp = MediaPlayer.create(this, R.raw.button);
                mp.start();
                clearMediaPlayer();
                setupMainView();
                break;
        }

    }

    private void setupFinishView()
    {
        ImageView apple1, apple2, apple3, apple4, apple5, apple6, apple7, apple8, apple9, star1, star2, star3, star4, star5, star6, star7;

        mp = MediaPlayer.create(this, R.raw.triumph);
        mp.start();
        clearMediaPlayer();

        View finishView = (View)findViewById(R.id.finishView);
        finishView.setVisibility(View.VISIBLE);

        ImageButton playAgain = (ImageButton) findViewById(R.id.PlayAgain);
        playAgain.setVisibility(ImageButton.VISIBLE);

        TextView answerText = (TextView) findViewById(R.id.CorrectAnswerText);
        answerText.setText(number1 + " + " + number2 + " = " + actualAnswer );
        answerText.setVisibility(TextView.VISIBLE);

        TextView correctMessage = (TextView) findViewById(R.id.CorrectMessage);
        correctMessage.setVisibility(TextView.VISIBLE);

        AnimationSet as = createAnimation();

        star1 = (ImageView)findViewById(R.id.star1);
        star1.setVisibility(ImageView.VISIBLE);
        star1.startAnimation(as);
        star2 = (ImageView)findViewById(R.id.star2);
        star2.setVisibility(ImageView.VISIBLE);
        star2.startAnimation(as);
        star4 = (ImageView)findViewById(R.id.star4);
        star4.setVisibility(ImageView.VISIBLE);
        star4.startAnimation(as);
        star5 = (ImageView)findViewById(R.id.star5);
        star5.setVisibility(ImageView.VISIBLE);
        star5.startAnimation(as);
        star6 = (ImageView)findViewById(R.id.star6);
        star6.startAnimation(as);
        star6.setVisibility(ImageView.VISIBLE);
        star7 = (ImageView)findViewById(R.id.star7);
        star7.setVisibility(ImageView.VISIBLE);
        star7.startAnimation(as);

        ConstraintLayout numberHolder = (ConstraintLayout)findViewById(R.id.numberContainer);
        numberHolder.setVisibility(View.GONE);

        ImageView tree = (ImageView)findViewById(R.id.Tree);
        tree.setVisibility(ImageView.INVISIBLE);

        apple1 = (ImageView)findViewById(R.id.apple1);
        apple1.setVisibility(ImageView.GONE);
        apple2 = (ImageView)findViewById(R.id.apple2);
        apple2.setVisibility(ImageView.GONE);
        apple3 = (ImageView)findViewById(R.id.apple3);
        apple3.setVisibility(ImageView.GONE);
        apple4 = (ImageView)findViewById(R.id.apple4);
        apple4.setVisibility(ImageView.GONE);
        apple5 = (ImageView)findViewById(R.id.apple5);
        apple5.setVisibility(ImageView.GONE);
        apple6 = (ImageView)findViewById(R.id.apple6);
        apple6.setVisibility(ImageView.GONE);
        apple7 = (ImageView)findViewById(R.id.apple7);
        apple7.setVisibility(ImageView.GONE);
        apple8 = (ImageView)findViewById(R.id.apple8);
        apple8.setVisibility(ImageView.GONE);
        apple9 = (ImageView)findViewById(R.id.apple9);
        apple9.setVisibility(ImageView.GONE);



    }

    private void setupMainView()
    {
        ImageView apple1, apple2, apple3, apple4, apple5, apple6, apple7, apple8, apple9, star1, star2, star4, star5, star6, star7;

        View finishView = (View)findViewById(R.id.finishView);
        finishView.setVisibility(View.INVISIBLE);

        ImageView playAgain = (ImageView)findViewById(R.id.PlayAgain);
        playAgain.setVisibility(ImageView.GONE);

        TextView answerText = (TextView) findViewById(R.id.CorrectAnswerText);
        answerText.setVisibility(View.INVISIBLE);

        TextView correctMessage = (TextView) findViewById(R.id.CorrectMessage);
        correctMessage.setVisibility(TextView.INVISIBLE);

        star1 = (ImageView)findViewById(R.id.star1);
        star1.setVisibility(ImageView.INVISIBLE);
        star1.clearAnimation();
        star2 = (ImageView)findViewById(R.id.star2);
        star2.setVisibility(ImageView.INVISIBLE);
        star2.clearAnimation();
        star4 = (ImageView)findViewById(R.id.star4);
        star4.setVisibility(ImageView.INVISIBLE);
        star4.clearAnimation();
        star5 = (ImageView)findViewById(R.id.star5);
        star5.setVisibility(ImageView.INVISIBLE);
        star5.clearAnimation();
        star6 = (ImageView)findViewById(R.id.star6);
        star6.setVisibility(ImageView.INVISIBLE);
        star6.clearAnimation();
        star7 = (ImageView)findViewById(R.id.star7);
        star7.clearAnimation();
        star7.setVisibility(ImageView.INVISIBLE);

        ConstraintLayout numberHolder = (ConstraintLayout)findViewById(R.id.numberContainer);
        numberHolder.setVisibility(View.VISIBLE);

        ImageView tree = (ImageView)findViewById(R.id.Tree);
        tree.setVisibility(ImageView.VISIBLE);

        apple1 = (ImageView)findViewById(R.id.apple1);
        apple1.setVisibility(ImageView.VISIBLE);
        apple2 = (ImageView)findViewById(R.id.apple2);
        apple2.setVisibility(ImageView.VISIBLE);
        apple3 = (ImageView)findViewById(R.id.apple3);
        apple3.setVisibility(ImageView.VISIBLE);
        apple4 = (ImageView)findViewById(R.id.apple4);
        apple4.setVisibility(ImageView.VISIBLE);
        apple5 = (ImageView)findViewById(R.id.apple5);
        apple5.setVisibility(ImageView.VISIBLE);
        apple6 = (ImageView)findViewById(R.id.apple6);
        apple6.setVisibility(ImageView.VISIBLE);
        apple7 = (ImageView)findViewById(R.id.apple7);
        apple7.setVisibility(ImageView.VISIBLE);
        apple8 = (ImageView)findViewById(R.id.apple8);
        apple8.setVisibility(ImageView.VISIBLE);
        apple9 = (ImageView)findViewById(R.id.apple9);
        apple9.setVisibility(ImageView.VISIBLE);

        createQuestion();
    }

    private AnimationSet createAnimation()
    {
        AlphaAnimation alpha = new AlphaAnimation(0,1);
        alpha.setDuration(250);
        alpha.setRepeatMode(Animation.REVERSE);
        alpha.setRepeatCount(Animation.INFINITE);

        RotateAnimation rotate = new RotateAnimation(0, 360, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f );
        rotate.setDuration(2500);
        rotate.setRepeatCount(Animation.INFINITE);

        ScaleAnimation scale = new ScaleAnimation(0,2,0,2, Animation.RELATIVE_TO_SELF, 0.5f, Animation.RELATIVE_TO_SELF, 0.5f);
        scale.setDuration(3000);
        scale.setRepeatMode(Animation.REVERSE);
        scale.setRepeatCount(Animation.INFINITE);

        AnimationSet as = new AnimationSet(true);
        as.addAnimation(alpha);
        as.addAnimation(rotate);
        as.addAnimation(scale);
        as.setStartOffset(0);

        return as;
    }

    private void clearMediaPlayer(){
        mp.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer p1) {
                p1.release();
            }
        });
    }
}